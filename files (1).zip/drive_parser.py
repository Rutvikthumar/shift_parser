def parse_drive_shifts(processed_ids):
    """
    Fetch and parse WhatsApp chat text files from Drive ZIPs, skipping processed_ids.
    Return: (list of shift dicts, list of new Drive file IDs)
    """
    # TODO: Implement Drive API, ZIP extraction, and parsing logic
    return [], []