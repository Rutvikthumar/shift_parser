def extract_shifts(text):
    """
    Parse shift info: dates, times, location, system, etc.
    Handles ranges, lists, multiple slots per day.
    """
    # TODO: Implement robust regexes and parsing for all formats required
    return []